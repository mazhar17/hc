# Building the test APK

I could not build this here: the sandbox blocks `dl.google.com`, `maven.google.com` and
`services.gradle.org`, and an APK cannot be produced without the Android SDK (`android.jar`,
`aapt2`, `d8`, `apksigner`) that lives on those servers. Everything else is done — this project
builds as it stands.

## The quickest route (Android Studio, ~10 minutes)

1. Install **Android Studio** (it brings the SDK and a JDK with it).
2. **Open** this `twa` folder as a project. Let it sync — it downloads the Android Gradle Plugin
   and `androidbrowserhelper` the first time.
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The file lands in `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and open
   it (you will have to allow "install unknown apps" once).

That APK is **debug-signed**: perfect for your own testing, not accepted by Play.

## From the command line instead

```bash
# with the Android SDK installed and ANDROID_HOME set
cd twa
./gradlew assembleDebug          # or: gradle assembleDebug
```

## Before it goes to Play

**1. Play wants an AAB, not an APK.** `Build → Generate Signed Bundle / APK → Android App Bundle`.

**2. Create your own upload key** — and keep it. If you lose it you cannot update the app.

```bash
keytool -genkey -v -keystore hifz-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

Store the file and its password somewhere you will still have them in five years. I have not
generated one for you on purpose: a signing key that has travelled through a chat is not a key
worth having.

**3. Publish `assetlinks.json` on the site.** Until you do, the app shows a browser address bar
across the top and looks like a web page in a box. Get the fingerprint of the key you signed with:

```bash
keytool -list -v -keystore hifz-upload.jks -alias upload | grep SHA256
```

Put that fingerprint into `wellknown/assetlinks.json` (next to this file), then upload it to the
repository so it is served at:

```
https://mazhar17.github.io/.well-known/assetlinks.json
```

**Note the path.** Digital Asset Links is checked at the **domain root**, not under `/hc/`. On
GitHub Pages that means the file belongs in your `mazhar17.github.io` repository, not in `hc`.
If you do not have that repository, create it — it can contain nothing else.

Once Play signs the app for you (App Signing), Play's own certificate fingerprint appears in the
Play Console under *Setup → App integrity*. **Add that one too** — the `assetlinks.json` file can
list several fingerprints, and the installed app is signed by Play's key, not yours.

**4. Also required by Play:** a privacy policy URL, the Data Safety form, a content rating
questionnaire, a feature graphic (1024×500), at least two screenshots, and a one-time $25
developer registration.

## What this app actually is

A Trusted Web Activity: a thin Android wrapper that opens `https://mazhar17.github.io/hc/`
full-screen in the device's own Chrome engine. Consequences worth knowing:

- **The APK is tiny** (a few hundred KB) and contains no Qur'anic text or Mushaf images.
- **Updates reach users when you redeploy the website.** You do not need a new Play release for
  every version — which, given how often you ship, is the main reason to prefer this over a
  wrapper that bundles the files.
- **It is the same app, with the same stored record** as the site in Chrome: same origin, same
  service worker, same localStorage. A user's progress carries across.
- **The first run needs internet.** After that the service worker serves it offline, exactly as
  the website already does.
- It needs Chrome (or another TWA-capable browser) present on the device. On the rare device
  without one, the helper falls back to a custom tab.

If you would rather the APK carry everything and never need the network at all, that is a
different build — a WebView app bundling `hifz-companion.html` (about 30 MB, with the compact
Mushaf inside). Say so and I will prepare that project instead; the trade-off is that every
release then needs a new Play upload.
