package io.github.mazhar17.hifz;

/**
 * The whole app. The helper library reads the URL and colours from the manifest above and opens
 * the site in a Trusted Web Activity, so the page runs in the device's own Chrome engine — the
 * same engine, the same service worker, the same stored record as the website.
 */
public class LauncherActivity extends com.google.androidbrowserhelper.trusted.LauncherActivity {
}
